#!/bin/bash

# grep relevant information from log files

echo ' *** Removing previous files ***'
rm TotalTime.csv DominantOperation.txt

echo ' *** Beginnning of postprocessing script ***'
EXT=out
for outputFile in *.${EXT}
do
    rm AllOperationsDummy.csv
    echo ' ... Processing file with name '${outputFile}
# Get time of current experiment
    grep 'Time (sec):' ${outputFile} | awk '{print $5}' >> TotalTime.csv
# Get converged reason
    grep 'Linear solve converged due to' ${outputFile} | head -1 | awk '{print $6}' >> ConvergedReason.csv
# Get dominant operation
    awk '/SNESSolve/,/PCApply/ {print $4, $1}' ${outputFile} >> AllOperationsDummy.csv
#echo -n ${outputFile} >> DominantOperation.txt
printf "%s `" ${outputFile} >> DominantOperation.txt
    sort -gr AllOperationsDummy.csv | awk 'FNR==3,FNR==5 {printf "%s " ,$2}' >> DominantOperation.txt
    sed -i '' -e '$a\' DominantOperation.txt
done

echo ' *** All data was collected succussfully ***'
