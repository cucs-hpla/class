#!/bin/bash

# shell script for running multiple configurations of solvers and preconditioners
# for grids of different sizes and with 3 picks for multiple processors.

echo ' *** Beginning of script ***'

# loop for ksp_type
for problemType in pipefgmres cg bcgsl
do
    # loop for pc_type
    for precType in bjacobi asm mg
    do
        # loop for mesh size (square matrices)
        for meshSize in 300
        do

            # loop for number of processors
            for np in 12
            do

                echo ' ... Processing mesh of size '$meshSize' x '$meshSize' using '$problemType' solver, '$precType' preconditioner, and '$np' processors'
                filename="log_ex19_${problemType}_${precType}_mesh${meshSize}_np${np}.out"

                # Run the problem using petsc and store all info in output file *.out
$PETSC_DIR/$PETSC_ARCH/bin/mpiexec -np ${np} ./ex19 -da_grid_x ${meshSize} -da_grid_y ${meshSize} -ksp_type ${problemType} -pc_type ${precType} -ksp_converged_reason -log_view > $filename
            done
        done
    done
done

echo ' *** All problems were successfully ran. End of script ***'
