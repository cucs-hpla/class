clear;
restoredefaultpath;

% Matlab code for postprocessing experiments data (hpla - HW03)
addpath('/Users/Aizen/tpls/petsc/src/snes/examples/tutorials/ex19Results');
%addpath('/Users/Aizen/tpls/petsc/src/snes/examples/tutorials/ex48Results');

totTime = load('TotalTime.csv');

fileID      = fopen('DominantOperation.txt','r');
formatSpec  = '%s %s %s %s';

domOper     = textscan(fileID,formatSpec);
probName    = domOper{1};
realDomOper = domOper{4};

pipefgmresTag = 1:27;
cgTag         = 28:54;
bcgslTag      = 55:81;
problemType   = {pipefgmresTag, cgTag, bcgslTag};

pcType1Tag = 1:9;
pcType2Tag = 10:18;
pcType3Tag = 19:27;
pcType     = {pcType1Tag, pcType2Tag, pcType3Tag};

meshL1Tag = 1:3;
meshL2Tag = 4:6;
meshL3Tag = 7:9;
mesh      = {meshL1Tag, meshL2Tag, meshL3Tag};

numProbType = 3; % num of pc type same as numProbType
organizedData = zeros(numProbType^2,numProbType^2);

% Plot for problem type
for iProbType = 1:numProbType
    currentProbTypeTime = totTime(problemType{iProbType});
    for iPcType = 1:numProbType
        currentProbAndPcTypeTime = currentProbTypeTime(pcType{iPcType});
        
        for iMesh = 1:numProbType
            currentProbPcTypeAndMeshTime = currentProbAndPcTypeTime(mesh{iMesh});
            for iNp = 1:numProbType
                currentProbPcTypeMeshAndProcTime = currentProbPcTypeAndMeshTime(iNp);
                
                % Plot data                
                organizedData(numProbType*(iProbType-1)+iPcType,numProbType*(iMesh-1)+iNp) = ...
                                    currentProbPcTypeMeshAndProcTime;
            end
        end
        
    end
end

%meshSizeStr = {'50x50','100x100','150x150'};
meshSizeStr = {'100x100','150x150','50x50'};
npStr       = {'2','4','8'};
figure(1);
for iMesh = 1:numProbType
    for iNp = 1:numProbType
                
        iCol = numProbType*(iMesh-1)+iNp;       
        
        subplot(3,3,iCol);
        plot(organizedData(:,iCol),'b*-'); grid on;
        sTitle = strcat('Experiment time for a',{' '},meshSizeStr{iMesh},' mesh and np =',{' '},npStr{iNp});
        title(sTitle);
        xlabel('Problem ID');
        ylabel('Time [s]');
    end
end
savefig('ex19_Results.fig');
%savefig('ex48_Results.fig');

% Same as previous but semilog plots
figure(2);
for iMesh = 1:numProbType
    for iNp = 1:numProbType
                
        iCol = numProbType*(iMesh-1)+iNp;       
        
        subplot(3,3,iCol);
        semilogy(organizedData(:,iCol),'b*-'); grid on;
        sTitle = strcat('Experiment time for a',{' '},meshSizeStr{iMesh},' mesh and np =',{' '},npStr{iNp});
        title(sTitle);
        xlabel('Problem ID');
        ylabel('Time [s]');
    end
end
savefig('ex19_Results_semilog.fig');
%savefig('ex48_Results_semilog.fig');

% Generate table with summary of problem types
f = figure(3);
set(f,'Position',[500 500 500 250]);
dat =  {1, 'pipefgmres','asm';...
        2, 'pipefgmres','bjacobi';...   
        3, 'pipefgmres','mg';...
        4, 'cg','asm';...
        5, 'cg','bjacobi';...
        6, 'cg','mg';...
        7, 'bcgsl','asm';...
        8, 'bcgsl','bjacobi';...
        9, 'bcgsl','mg';};
columnname =   {'x-label Id', 'SolverType', 'Precond Type'};
columnformat = {'numeric', 'char', 'char' }; 
t = uitable('Units','normalized','Position',...
            [0.05 0.05 0.55 0.87], 'Data', dat,... 
            'ColumnName', columnname,...
            'ColumnFormat', columnformat,...
            'RowName',[]);
        