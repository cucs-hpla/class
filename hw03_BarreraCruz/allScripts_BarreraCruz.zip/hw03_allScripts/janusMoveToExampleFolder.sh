# !/bin/bash

mkdir ex19Results
cp *.sh *.out *.txt *.csv ex19Results/
