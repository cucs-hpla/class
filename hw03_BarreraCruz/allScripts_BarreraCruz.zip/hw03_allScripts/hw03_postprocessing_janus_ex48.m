%%%%%%%%%%%%%%%%%%%%%%%%%
% MATLAB SCRIPT FOR JANUS 
%%%%%%%%%%%%%%%%%%%%%%%%%

clear;
restoredefaultpath;

% Matlab code for postprocessing experiments data (hpla - HW03)

totTime = load('TotalTime.csv');
totTimeMin = totTime./60;

figure(1);
plot(totTimeMin,'b*-'); grid on;
sTitle = strcat('JANUS experiment times for a 250x250 mesh and 12 processors (ex48)');
title(sTitle);
xlabel('Problem ID');
ylabel('Time [min]');
savefig('ex48_janusResults.fig');

% Generate table with summary of problem types
f = figure(2);
set(f,'Position',[500 500 500 250]);
dat =  {1, 'pipefgmres','asm';...
        2, 'pipefgmres','bjacobi';...   
        3, 'pipefgmres','mg';...
        4, 'cg','asm';...
        5, 'cg','bjacobi';...
        6, 'cg','mg';};
columnname =   {'x-label Id', 'SolverType', 'Precond Type'};
columnformat = {'numeric', 'char', 'char' }; 
t = uitable('Units','normalized','Position',[0.05 0.05 0.55 0.87], 'Data', dat,... 
            'ColumnName', columnname,'ColumnFormat', columnformat,'RowName',[]);
        